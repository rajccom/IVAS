-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2023 at 01:25 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wockhardt_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `address_details`
--

CREATE TABLE `address_details` (
  `id` int(20) NOT NULL,
  `title` varchar(75) NOT NULL,
  `address` varchar(1500) NOT NULL,
  `location` varchar(100) NOT NULL,
  `location_id` int(20) NOT NULL,
  `state` varchar(50) NOT NULL,
  `state_id` int(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` int(10) NOT NULL,
  `direction` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address_details`
--

INSERT INTO `address_details` (`id`, `title`, `address`, `location`, `location_id`, `state`, `state_id`, `city`, `pincode`, `direction`) VALUES
(1, 'ccomdigital', 'C Com Digital, 10, Wadala Udyog Bhavan, Naigaon Cross Road, Telephone Exchn, near Wadala, Wadala, Mumbai, Maharashtra 400031', 'Wadala', 1, 'Maharashtra', 1, 'Mumbai', 400031, 'https://www.google.com/maps/dir//c+com+digital+on+google+map/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x3be7cee06834027f:0xaf5bd233813a99a1?sa=X&ved=2ahUKEwjPmrG8x7_9AhV7TmwGHVJnAdkQ9Rd6BAgwEAU'),
(2, 'I.C.E Asia Pvt Limited', 'India Printing House, 202, G D Ambekar Rd, Sahakar Nagar, Wadala, Mumbai, Maharashtra 400031', 'Wadala', 1, 'Maharashtra', 1, 'Mumbai', 400031, 'https://www.google.com/maps/dir//c+com+digital+on+google+map/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x3be7cee06834027f:0xaf5bd233813a99a1?sa=X&ved=2ahUKEwjPmrG8x7_9AhV7TmwGHVJnAdkQ9Rd6BAgwEAU'),
(3, 'Rajdeep Automation Pvt Ltd', ' B-27 3rd Floor, Shriram Industrial Estate, 13, G D Ambedkar Road, Wadala, Wadala, Mumbai, Maharashtra 400031', 'Wadala', 1, 'Maharashtra', 1, 'Mumbai', 400031, 'https://www.google.com/maps/dir//c+com+digital+on+google+map/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x3be7cee06834027f:0xaf5bd233813a99a1?sa=X&ved=2ahUKEwjPmrG8x7_9AhV7TmwGHVJnAdkQ9Rd6BAgwEAU'),
(4, 'RJ Group of Companies', '201, Awaas CHS, Pralhad Nagar, Ahmedabad, Gujarat - 380001', 'Pralhad Nagar', 3, 'Gujarat', 1, 'Ahmedabad', 380001, 'https://www.google.com/maps/dir//c+com+digital+on+google+map/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x3be7cee06834027f:0xaf5bd233813a99a1?sa=X&ved=2ahUKEwjPmrG8x7_9AhV7TmwGHVJnAdkQ9Rd6BAgwEAU'),
(5, 'Netcore Cloud', 'Peninsula Towers, Peninsula Corporate Park, Peninsula Tower\'s Walk way, Lower Parel West, Lower Parel, Mumbai, Maharashtra 400013', 'Lower Parel', 2, 'Maharashtra', 1, 'Mumbai', 400013, 'https://www.google.com/maps/dir//c+com+digital+on+google+map/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x3be7cee06834027f:0xaf5bd233813a99a1?sa=X&ved=2ahUKEwjPmrG8x7_9AhV7TmwGHVJnAdkQ9Rd6BAgwEAU');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` int(11) NOT NULL,
  `city_name` text NOT NULL,
  `state_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`, `state_id`) VALUES
(1, 'Mumbai', 1),
(2, 'Pune', 1),
(3, 'Nagpur', 1),
(4, 'New Delhi', 2),
(5, 'Taj Pul', 2),
(6, 'Mandoli', 2),
(7, 'Vishakhapatnam', 4),
(8, 'Tirupati', 4),
(9, 'Rajarhat Gopalpur', 5),
(10, 'Bhatpara', 5),
(11, 'Panihati', 5),
(12, 'Amritsar', 6),
(13, 'Ludhiana', 6),
(14, 'Ahmedabad', 7),
(15, 'Surat', 7);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` int(25) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `intrest` int(20) NOT NULL DEFAULT 2 COMMENT '1 - Intrested, 2 - Not Intrested  '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `sname`, `phone`, `email`, `city`, `intrest`) VALUES
(1, 'raj', '7045563425', 'rajkadam7045@gmail.com', 'Mumbai', 2),
(2, 'Raj', '7045563425', 'rajkadam7045@gmail.com', 'Mumbai', 2),
(3, 'Raj', '7045563425', 'rajkadam7045@gmail.com', 'Chennai', 2),
(4, 'Ankit', '9892904587', 'rajkadam7045@gmail.com', 'CCOm', 2),
(5, '', '', '', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(20) NOT NULL,
  `product_name` varchar(120) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `size` char(20) NOT NULL,
  `finish` varchar(50) NOT NULL,
  `concept` varchar(20) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_quantity` mediumint(5) NOT NULL,
  `product_status` enum('0','1') NOT NULL COMMENT '0-active,1-inactive'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `category`, `size`, `finish`, `concept`, `product_image`, `product_quantity`, `product_status`) VALUES
(1, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(2, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'Bath tub.webp', 5, '1'),
(3, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(4, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'Bath tub.webp', 5, '1'),
(5, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(6, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'image-2.jpeg', 5, '1'),
(7, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(8, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'image-2.jpeg', 5, '1'),
(9, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(10, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'image-2.jpeg', 5, '1'),
(11, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(12, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'image-2.jpeg', 5, '1'),
(13, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(14, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'image-2.jpeg', 5, '1'),
(15, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(16, 'Hardrock White', 'Glazed Vitrified Tiles', '600x600 mm', 'Matt', '3D', 'image-2.jpeg', 5, '1'),
(17, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 10, '1'),
(18, 'Emperador Grey', 'Slabs', '800x1600 mm', 'Polish', 'Book Match', 'image-1.jpeg', 25, '1');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(20) NOT NULL,
  `state_name` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `state_name`) VALUES
(1, 'Maharashtra'),
(2, 'Delhi'),
(3, 'Gujarat'),
(4, 'Uttar Pradesh'),
(5, 'Sikkim'),
(6, 'Tamil Nadu'),
(7, 'Telangana'),
(8, 'West Bengal'),
(9, 'Madhya Pradesh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address_details`
--
ALTER TABLE `address_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address_details`
--
ALTER TABLE `address_details`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
